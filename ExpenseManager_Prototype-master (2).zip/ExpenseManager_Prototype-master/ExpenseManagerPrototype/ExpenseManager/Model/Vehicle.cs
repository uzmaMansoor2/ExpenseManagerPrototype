﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExpenseManager.Model
{
    public class Vehicle
    {
        public string numberPlate { get; set; }
        public string make { get; set; }
        public string model { get; set; }
    }
}
